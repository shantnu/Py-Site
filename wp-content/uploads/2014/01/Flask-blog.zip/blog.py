from flask import *
from functools import wraps

SECRET_KEY = "Chocolate Chip Cookies"
app = Flask(__name__)
app.config.from_object(__name__)

posts = ["My first blog"]

@app.route("/")
def home(name = None):
    return render_template("index.html", name = name)

@app.route("/login", methods = ["GET", "POST"])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] == "fish" and request.form["password"] == "chips":
            session["logged_in"] = True
            return redirect(url_for("secret"))
        else:
            error = "Username or password wrong, dude"
        
    return render_template("login.html", error = error)

def login_required(test):
    @wraps(test)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return test(*args, **kwargs)
        else:
            return redirect(url_for('login'))
        
    return wrap

@app.route("/secret")
@login_required
def secret():
    return render_template("secret.html", posts = posts)

@app.route('/add', methods = ["POST"])
def add():
    blog = request.form['post']
    posts.append(blog)
    
    return redirect(url_for("secret"))

@app.route("/logout")
def logout():
    session.pop("logged_in", None)
    return redirect(url_for("login"))

app.run(debug=True)