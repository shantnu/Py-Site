from flask import *

app = Flask(__name__)

@app.route("/")
@app.route("/<name>")
def home(name = None):
    return render_template("index.html", name = name)

app.run(debug=True)