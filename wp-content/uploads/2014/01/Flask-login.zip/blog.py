from flask import *
SECRET_KEY = "Chocolate Chip Cookies"
app = Flask(__name__)
app.config.from_object(__name__)

@app.route("/")
def home(name = None):
    return render_template("index.html", name = name)

@app.route("/login", methods = ["GET", "POST"])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] == "fish" and request.form["password"] == "chips":
            session["logged_in"] = True
            return redirect(url_for("secret"))
        else:
            error = "Username or password wrong, dude"
        
    return render_template("login.html", error = error)

@app.route("/secret")
def secret():
    return render_template("secret.html")

@app.route("/logout")
def logout():
    session.pop("logged_in", None)
    return redirect(url_for("login"))

app.run(debug=True)